
import React, {useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import {
  ArrowUpRight, ArrowRight, Menu, X, Check, BarChart3, WalletCards,
  Boxes, UsersRound, Workflow, Sparkles, ChevronDown
} from "lucide-react";
import "./styles.css";

const translations = {
  en: {
    nav:["Solutions","Approach","For SMEs","Our idea","Contact"],
    heroKicker:"BUSINESS INTELLIGENCE · TECHNOLOGY · IMPROVEMENT",
    heroTitle:<>Turn business data into <i>better decisions.</i></>,
    heroText:"Madhinutpam helps growing businesses make sense of the data they already have, improve the way they work, and act with clarity.",
    primary:"Start a conversation",
    secondary:"Explore what we do",
    trusted:"Built around your business — not around a software package.",
    health:"BUSINESS PULSE",
    healthy:"Healthy",
    sales:"Sales",
    receivables:"Receivables",
    attention:"Attention",
    attentionText:"3 customers account for 41% of overdue receivables.",
    ask:"ASK YOUR BUSINESS",
    question:"இந்த வாரம் விற்பனை ஏன் குறைந்தது?",
    solveKicker:"WHAT WE SOLVE",
    solveTitle:<>The missing layer between <i>your data</i> and action.</>,
    solveText:"You already have numbers. We help turn them into visibility, understanding and practical next steps.",
    whyKicker:"WHY MADHINUTPAM",
    whyTitle:<>Technology should fit your business. <i>Not the other way around.</i></>,
    whyText:"We don't begin by selling a platform. We begin by understanding how your business works, where decisions get stuck, and what would actually make a difference.",
    approachKicker:"HOW WE WORK",
    approachTitle:<>Small steps. <i>Real improvement.</i></>,
    ideaKicker:"THE MADHINUTPAM IDEA",
    ideaTitle:<>Intelligence is useful only when it <i>improves a decision.</i></>,
    contactKicker:"LET'S TALK",
    contactTitle:<>Tell us the business problem. <i>We'll find the opportunity.</i></>,
    contactText:"You don't need to know which technology you need. Tell us what is difficult today.",
    send:"Send enquiry",
    phone:"PHONE / WHATSAPP",
    email:"EMAIL",
    kural:"மதிநுட்பம் நூலோடு உடையார்க்கு\nஅதிநுட்பம் யாவுள முன்நிற் பவை.",
    kuralMeaning:"இயற்கையான நுண்ணறிவுடன் கற்றறிந்த அறிவையும் கொண்டவர்களுக்கு, எதிரில் வரும் சிக்கல்கள் மிக நுட்பமானதாக இருக்க முடியாது.",
  },
  ta: {
    nav:["தீர்வுகள்","எங்கள் அணுகுமுறை","SME நிறுவனங்கள்","எங்கள் சிந்தனை","தொடர்பு"],
    heroKicker:"வணிக நுண்ணறிவு · தொழில்நுட்பம் · மேம்பாடு",
    heroTitle:<>வணிகத் தரவை <i>சிறந்த முடிவுகளாக</i> மாற்றுங்கள்.</>,
    heroText:"மதிநுட்பம், உங்கள் வணிகத்தில் ஏற்கனவே உள்ள தரவைப் புரிந்துகொள்ளவும், செயல்முறைகளை மேம்படுத்தவும், தெளிவுடன் செயல்படவும் உதவுகிறது.",
    primary:"உரையாடலைத் தொடங்குங்கள்",
    secondary:"நாங்கள் செய்வதைப் பாருங்கள்",
    trusted:"உங்கள் வணிகத்திற்காக — ஒரு மென்பொருள் தொகுப்பிற்காக அல்ல.",
    health:"வணிக நிலை",
    healthy:"நலமாக உள்ளது",
    sales:"விற்பனை",
    receivables:"வரவேண்டிய தொகை",
    attention:"கவனம்",
    attentionText:"நிலுவைத் தொகையில் 41% மூன்று வாடிக்கையாளர்களிடமிருந்து வரவேண்டும்.",
    ask:"உங்கள் வணிகத்திடம் கேளுங்கள்",
    question:"இந்த வாரம் விற்பனை ஏன் குறைந்தது?",
    solveKicker:"நாங்கள் தீர்க்கும் சிக்கல்கள்",
    solveTitle:<>உங்கள் <i>தரவு</i> மற்றும் செயலுக்கு இடையிலான இடைவெளியை நிரப்புகிறோம்.</>,
    solveText:"உங்களிடம் ஏற்கனவே எண்கள் உள்ளன. அவற்றை தெளிவு, புரிதல் மற்றும் நடைமுறை அடுத்த நடவடிக்கைகளாக மாற்ற உதவுகிறோம்.",
    whyKicker:"ஏன் மதிநுட்பம்",
    whyTitle:<>தொழில்நுட்பம் உங்கள் வணிகத்திற்குப் பொருந்த வேண்டும். <i>மாறாக அல்ல.</i></>,
    whyText:"முதலில் ஒரு தளத்தை விற்கத் தொடங்குவதில்லை. உங்கள் வணிகம் எப்படி இயங்குகிறது, முடிவுகள் எங்கு தடைபடுகின்றன, உண்மையில் எது மாற்றத்தை உருவாக்கும் என்பதைப் புரிந்துகொள்கிறோம்.",
    approachKicker:"எங்கள் அணுகுமுறை",
    approachTitle:<>சிறிய படிகள். <i>உண்மையான முன்னேற்றம்.</i></>,
    ideaKicker:"மதிநுட்பத்தின் சிந்தனை",
    ideaTitle:<>ஒரு முடிவை மேம்படுத்தும்போதுதான் நுண்ணறிவு <i>பயனுள்ளதாகிறது.</i></>,
    contactKicker:"உரையாடுவோம்",
    contactTitle:<>வணிகச் சிக்கலைச் சொல்லுங்கள். <i>வாய்ப்பைக் கண்டறிவோம்.</i></>,
    contactText:"உங்களுக்கு எந்த தொழில்நுட்பம் தேவை என்பதை நீங்கள் அறிந்திருக்க வேண்டியதில்லை. இன்று எது சிரமமாக உள்ளது என்பதைச் சொல்லுங்கள்.",
    send:"விசாரணையை அனுப்புங்கள்",
    phone:"தொலைபேசி / வாட்ஸ்அப்",
    email:"மின்னஞ்சல்",
    kural:"மதிநுட்பம் நூலோடு உடையார்க்கு\nஅதிநுட்பம் யாவுள முன்நிற் பவை.",
    kuralMeaning:"இயற்கையான நுண்ணறிவுடன் கற்றறிந்த அறிவையும் கொண்டவர்களுக்கு, எதிரில் வரும் சிக்கல்கள் மிக நுட்பமானதாக இருக்க முடியாது.",
  }
};

const services = [
 {icon:BarChart3,en:["Sales intelligence","See movement, trends, gaps and opportunities before they become problems."],ta:["விற்பனை நுண்ணறிவு","விற்பனை மாற்றங்கள், போக்குகள் மற்றும் வாய்ப்புகளை தெளிவாகப் பாருங்கள்."]},
 {icon:WalletCards,en:["Cash & receivables","Know where cash is stuck, who owes you and what needs attention."],ta:["பணப்புழக்கம் & வரவேண்டிய தொகை","பணம் எங்கு சிக்கியுள்ளது, யார் தர வேண்டும் என்பதை அறியுங்கள்."]},
 {icon:Boxes,en:["Inventory intelligence","Find slow-moving stock, stock-outs and working-capital pressure."],ta:["சரக்கு நுண்ணறிவு","மெதுவாக நகரும் சரக்கு, பற்றாக்குறை மற்றும் மூலதன அழுத்தத்தை கண்டறியுங்கள்."]},
 {icon:UsersRound,en:["Customer intelligence","Understand inactive customers, concentration and follow-up opportunities."],ta:["வாடிக்கையாளர் நுண்ணறிவு","செயலற்ற வாடிக்கையாளர்கள் மற்றும் தொடர்ச்சியான தொடர்பு வாய்ப்புகளை அறியுங்கள்."]},
 {icon:Workflow,en:["Process improvement","Identify repetitive work where technology can save time and reduce errors."],ta:["செயல்முறை மேம்பாடு","நேரத்தை மிச்சப்படுத்தும் மற்றும் பிழைகளை குறைக்கும் வாய்ப்புகளை கண்டறியுங்கள்."]},
 {icon:Sparkles,en:["Decision systems","Bring the right information together so owners can act with confidence."],ta:["முடிவெடுக்கும் அமைப்புகள்","சரியான தகவலை ஒன்றிணைத்து தெளிவான முடிவெடுக்க உதவுங்கள்."]}
];

const steps = [
 ["01","Understand","புரிந்துகொள்","Business, people, processes and data."],
 ["02","Identify","கண்டறி","Find the highest-value problem to solve."],
 ["03","Build","உருவாக்கு","Create a practical solution around what exists."],
 ["04","Measure","அளவிடு","Track whether the business actually improves."]
];

function App(){
 const [lang,setLang]=useState(localStorage.getItem("madhinutpam-lang")||"en");
 const [open,setOpen]=useState(false);
 const t=translations[lang];
 useEffect(()=>localStorage.setItem("madhinutpam-lang",lang),[lang]);
 const go=(id)=>{setOpen(false);document.getElementById(id)?.scrollIntoView({behavior:"smooth"});}
 return <div className={lang==="ta"?"app tamil":"app"}>
  <div className="announcement"><div>Practical intelligence for growing businesses.</div><div className="announceRight"><a href="tel:+919698386652">+91 96983 86652</a><a href="mailto:kathirveleswaran831@gmail.com">kathirveleswaran831@gmail.com</a></div></div>
  <header className="header"><div className="nav">
   <button className="brand" onClick={()=>go("home")}><span>ம</span><b>MADHINUTPAM<small>மதிநுட்பம்</small></b></button>
   <nav className={open?"navOpen":""}>{t.nav.map((x,i)=><button key={x} onClick={()=>go(["solutions","approach","business","idea","contact"][i])}>{x}</button>)}</nav>
   <div className="navTools"><div className="switch"><button className={lang==="en"?"on":""} onClick={()=>setLang("en")}>EN</button><button className={lang==="ta"?"on":""} onClick={()=>setLang("ta")}>தமிழ்</button></div><button className="talk" onClick={()=>go("contact")}>{t.primary}<ArrowUpRight size={15}/></button><button className="hamb" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button></div>
  </div></header>

  <main>
   <section className="hero" id="home"><div className="heroGlow"></div><div className="heroGrid">
    <div className="heroText"><div className="eyebrow">{t.heroKicker}</div><h1>{t.heroTitle}</h1><p>{t.heroText}</p><div className="heroButtons"><button className="primary" onClick={()=>go("contact")}>{t.primary}<ArrowRight/></button><button className="secondary" onClick={()=>go("solutions")}>{t.secondary}</button></div><div className="proof"><Check/> Existing systems <span>·</span><Check/> Practical implementation <span>·</span><Check/> Measurable improvement</div></div>
    <div className="heroVisual">
      <div className="visualTop"><span>{t.health}</span><b>LIVE OWNER VIEW</b></div>
      <div className="visualScore"><div><small>{t.healthy}</small><strong>78</strong><span>/100</span></div><div className="pulse"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div></div>
      <div className="miniMetrics"><div><small>{t.sales}</small><strong>+12.4%</strong><em>vs last month</em></div><div><small>{t.receivables}</small><strong>₹8.4L</strong><em>needs attention</em></div></div>
      <div className="attention"><div className="spark">✦</div><div><small>{t.attention}</small><b>{t.attentionText}</b></div></div>
      <div className="question"><small>{t.ask}</small><span>“{t.question}”</span><ArrowUpRight/></div>
    </div>
   </div><div className="trusted"><span>{t.trusted}</span><div><b>TALLY</b><b>EXCEL</b><b>ERP</b><b>CRM</b><b>BILLING</b></div></div></section>

   <section className="section solutions" id="solutions"><div className="sectionIntro"><div><label>{t.solveKicker}</label><h2>{t.solveTitle}</h2></div><p>{t.solveText}</p></div><div className="serviceGrid">{services.map((s,i)=>{const Icon=s.icon;const d=s[lang];return <article className="service" key={i}><div className="icon"><Icon/></div><span className="num">0{i+1}</span><h3>{d[0]}</h3><p>{d[1]}</p><button onClick={()=>go("contact")}>Explore <ArrowUpRight/></button></article>})}</div></section>

   <section className="darkBand" id="business"><div className="darkGrid"><div><label>WHY MADHINUTPAM</label><h2>{t.whyTitle}</h2><p>{t.whyText}</p><button className="limeBtn" onClick={()=>go("contact")}>{t.primary}<ArrowUpRight/></button></div><div className="principles"><div><b>01</b><h3>Business first</h3><p>Start with the real business problem.</p></div><div><b>02</b><h3>Existing data</h3><p>Work with what you already have.</p></div><div><b>03</b><h3>Simple for owners</h3><p>Clear answers, not complicated dashboards.</p></div><div><b>04</b><h3>Outcome driven</h3><p>Measure whether the business improves.</p></div></div></div></section>

   <section className="section approach" id="approach"><div className="sectionIntro"><div><label>{t.approachKicker}</label><h2>{t.approachTitle}</h2></div><p>Consult → Identify → Solve → Measure. Then repeat what works.</p></div><div className="steps">{steps.map((s,i)=><div className={i===0?"active":""} key={s[0]}><b>{s[0]}</b><h3>{lang==="ta"?s[2]:s[1]}</h3><p>{s[3]}</p><ArrowRight/></div>)}</div></section>

   <section className="idea" id="idea"><div className="ideaInner"><div className="kural"><span>திருக்குறள் · 636</span><blockquote>{t.kural}</blockquote><p>{t.kuralMeaning}</p></div><div className="ideaText"><label>{t.ideaKicker}</label><h2>{t.ideaTitle}</h2><div className="flow"><span>Data</span><i>→</i><span>Insight</span><i>→</i><span>Decision</span><i>→</i><span>Action</span><i>→</i><strong>Result</strong></div></div></div></section>

   <section className="contact" id="contact"><div className="contactGrid"><div><label>{t.contactKicker}</label><h2>{t.contactTitle}</h2><p>{t.contactText}</p><div className="contactCards"><a href="tel:+919698386652"><small>{t.phone}</small><b>+91 96983 86652</b></a><a href="mailto:kathirveleswaran831@gmail.com"><small>{t.email}</small><b>kathirveleswaran831@gmail.com</b></a></div></div><form onSubmit={e=>{e.preventDefault();const f=new FormData(e.currentTarget);const body=`Name: ${f.get("name")}\\nBusiness: ${f.get("business")}\\nPhone: ${f.get("phone")}\\nChallenge: ${f.get("challenge")}\\nMessage: ${f.get("message")}`;location.href=`mailto:kathirveleswaran831@gmail.com?subject=Madhinutpam Business Enquiry&body=${encodeURIComponent(body)}`}}><div className="formHead"><span>01</span><h3>Start a conversation</h3></div><input name="name" required placeholder="Your name"/><input name="business" required placeholder="Business name"/><input name="phone" required placeholder="Phone / WhatsApp"/><select name="challenge"><option>Sales & customer visibility</option><option>Cash flow & receivables</option><option>Inventory</option><option>Reporting / MIS</option><option>Process improvement</option><option>Not sure — I want to discuss</option></select><textarea name="message" rows="3" placeholder="What is difficult in your business?"></textarea><button className="primary" type="submit">{t.send}<ArrowRight/></button></form></div></section>
  </main>
  <footer><div className="footerTop"><button className="brand" onClick={()=>go("home")}><span>ம</span><b>MADHINUTPAM<small>மதிநுட்பம்</small></b></button><p>அறிவை ஆற்றலாக்கி, வளர்ச்சியை உருவாக்குதல்.</p><div><a href="tel:+919698386652">+91 96983 86652</a><a href="mailto:kathirveleswaran831@gmail.com">kathirveleswaran831@gmail.com</a></div></div><div className="footerBottom"><span>© 2026 Madhinutpam. All rights reserved.</span><span>Intelligence for better business.</span></div></footer>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);
